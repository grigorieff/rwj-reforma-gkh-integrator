var myMap;

ymaps.ready(init);

function init () {
	var myGeocoder = ymaps.geocode('Стерлитамак, ул. Худайбердина, д. 73');
	myGeocoder.then(
		function (res) {
			myMap = new ymaps.Map('rwj-integrator-ymap', {
				center: res.geoObjects.get(0).geometry.getCoordinates(),
				zoom:15
			});
			var placemark = new YMaps.Placemark(res.geoObjects.get(0).geometry.getCoordinates());
			myMap.addOverlay(placemark); 
		},
		function (err) {
			alert('Ошибка');
		}
	);
}
